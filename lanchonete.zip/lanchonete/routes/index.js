const express = require('express');
const router = express.Router();

//Importar outros routers
const clientesRouter = require('./clientes');
const cardapioRouter = require('./cardapio');
const authRouter = require('./auth');
const { version } = require('os');

//Rota principal
router.get('/', (req, res) => {
    res.json({
        message: 'API da Lanchonete do Palilo'
        version: '1.0.0',
        endpoints: {
            clientes: '/api/clientes',
            cardapio: '/api/cardapio',
            auth: '/api/auth'
        }
    });
});

//Usar sub-routers
router.use('/clientes', usuariosRouter);
router.use('/cardapio', cardapioRouter);
router.use('/auth', authRouter);

module.exports = router;